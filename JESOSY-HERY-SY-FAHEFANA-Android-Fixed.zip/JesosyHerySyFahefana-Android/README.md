# JESOSY HERY SY FAHEFANA — Lyrics Offline
Android Native Application (Kotlin + Jetpack Compose + Room Database)

Développé par: **Tendry Fanomezantsoa RAKOTONANAHARY**  
Taona: **2026**

---

## 📖 Toetoetra sy Fiasan'ny Fampiharana (Features)

1. **100% Offline**: Tsy mila aterineto (Internet) mihitsy aorian'ny fametrahana azy.
2. **Room Local Database**: Tahiry matanjaka sy haingana ho an'ny tononkira, sokajy ary mamin'ny fo.
3. **Fitadiavana Haingana (Instant Search)**: Fitadiavana ara-potoana amin'ny lohateny, andininy, mpanoratra na laharana.
4. **Toerana Mpitantana Miafina (Admin Dashboard)**: Fampidirana, fanovana ary famafana hira sy sokajy amin'ny alalan'ny kaody PIN fiarovana (Par défaut: 7777).
5. **Mpamakafaka Tononkira (Lyrics Reader)**:
   - Fanalehibiazana na fampihenana ny haben'ny soratra (Font size A- / A+)
   - Fanamorana ny fihirana mandeha ho azy (Smooth Auto-scroll miaraka amin'ny hafainganam-pandeha)
   - Fizarana tononkira (Share intent)
   - Fanamarihana ho mamin'ny fo (Favorites)
6. **Animated Splash Screen**: Fanehoana ny hafatra « Tahin Jesosy 🙏 ».
7. **Drafitra sy Loko**: Obsidian Black, Royal Gold (#D4AF37), ary Divine Purple.

---

## 🛠️ Fomba Fandrafetana sy Fananganana (How to Build & Compile)

### Safidy 1: Amin'ny alalan'ny GitHub Actions (Tsy mila Android Studio)
1. Atsofohy ao amin'ny GitHub Repository ity tetikasa ity.
2. Mandehana ao amin'ny **Actions** tab ao amin'ny GitHub.
3. Ny workflow `.github/workflows/android_build.yml` dia hanamboatra ho azy ny APK (*JesosyHerySyFahefana-Debug-APK*).
4. Raiso avy hatrany ny rakitra APK (.apk) azo apetraka amin'ny finday Android rehetra!

### Safidy 2: Amin'ny alalan'ny Android Studio
1. Sokafy ny **Android Studio** (Ladybug / Meerkat na vaovao kokoa).
2. Fidio ny **Open Project** ary safidio ity lahatahiry `JesosyHerySyFahefana-Android` ity.
3. Andraso ho vita ny Gradle Sync.
4. Tsindrio ny **Run** (maitso) na **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

### Safidy 3: Amin'ny alalan'ny Terminal / Ligne de Commande
```bash
# Linux / macOS
chmod +x gradlew
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```
Ny APK vita dia ho hita ao amin'ny: `app/build/outputs/apk/debug/app-debug.apk`.

---

© 2026 Tendry Fanomezantsoa RAKOTONANAHARY. Zo rehetra voatokana.
