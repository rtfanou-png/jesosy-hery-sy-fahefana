# Add project specific ProGuard rules here.
-keep class mg.jesosy.hery.fahefana.data.local.** { *; }
-dontwarn androidx.room.paging.**
