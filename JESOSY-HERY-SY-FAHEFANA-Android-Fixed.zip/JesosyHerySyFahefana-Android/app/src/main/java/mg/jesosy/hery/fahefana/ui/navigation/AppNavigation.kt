package mg.jesosy.hery.fahefana.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import mg.jesosy.hery.fahefana.data.local.AppDatabase
import mg.jesosy.hery.fahefana.data.repository.SongRepository
import mg.jesosy.hery.fahefana.ui.components.BottomNavigationBar
import mg.jesosy.hery.fahefana.ui.screens.*
import mg.jesosy.hery.fahefana.ui.viewmodels.AdminViewModel
import mg.jesosy.hery.fahefana.ui.viewmodels.AdminViewModelFactory
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModel
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModelFactory

@Composable
fun AppNavigation(navController: NavHostController) {
    val context = LocalContext.current
    val database = remember { AppDatabase.getDatabase(context) }
    val repository = remember { SongRepository(database.songDao()) }

    val mainViewModel: MainViewModel = viewModel(factory = MainViewModelFactory(repository))
    val adminViewModel: AdminViewModel = viewModel(factory = AdminViewModelFactory(repository, context))

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Search.route,
        Screen.Categories.route,
        Screen.Favorites.route,
        Screen.Settings.route
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavigationBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onAnimationEnd = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = mainViewModel,
                    onSongClick = { songId ->
                        navController.navigate(Screen.LyricsReader.createRoute(songId))
                    },
                    onSearchClick = {
                        navController.navigate(Screen.Search.route)
                    },
                    onCategoryClick = { catId ->
                        mainViewModel.setSelectedCategory(catId)
                        navController.navigate(Screen.Categories.route)
                    },
                    onOpenAdmin = {
                        if (adminViewModel.isAuthenticated.value) {
                            navController.navigate(Screen.AdminDashboard.route)
                        } else {
                            navController.navigate(Screen.AdminLogin.route)
                        }
                    },
                    onOpenAbout = {
                        navController.navigate(Screen.About.route)
                    }
                )
            }

            composable(Screen.Search.route) {
                SearchScreen(
                    viewModel = mainViewModel,
                    onSongClick = { songId ->
                        navController.navigate(Screen.LyricsReader.createRoute(songId))
                    }
                )
            }

            composable(Screen.Categories.route) {
                CategoriesScreen(
                    viewModel = mainViewModel,
                    onSongClick = { songId ->
                        navController.navigate(Screen.LyricsReader.createRoute(songId))
                    }
                )
            }

            composable(Screen.Favorites.route) {
                FavoritesScreen(
                    viewModel = mainViewModel,
                    onSongClick = { songId ->
                        navController.navigate(Screen.LyricsReader.createRoute(songId))
                    }
                )
            }

            composable(
                route = Screen.LyricsReader.route,
                arguments = listOf(navArgument("songId") { type = NavType.LongType })
            ) { backStackEntry ->
                val songId = backStackEntry.arguments?.getLong("songId") ?: 1L
                LyricsReaderScreen(
                    songId = songId,
                    viewModel = mainViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.AdminLogin.route) {
                AdminLoginScreen(
                    viewModel = adminViewModel,
                    onSuccess = {
                        navController.navigate(Screen.AdminDashboard.route) {
                            popUpTo(Screen.AdminLogin.route) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.AdminDashboard.route) {
                AdminDashboardScreen(
                    viewModel = adminViewModel,
                    mainViewModel = mainViewModel,
                    onAddSong = {
                        navController.navigate(Screen.AdminAddEditSong.createRoute(null))
                    },
                    onEditSong = { songId ->
                        navController.navigate(Screen.AdminAddEditSong.createRoute(songId))
                    },
                    onLogout = {
                        adminViewModel.logout()
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.AdminDashboard.route) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Screen.AdminAddEditSong.route,
                arguments = listOf(navArgument("songId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                })
            ) { backStackEntry ->
                val songIdStr = backStackEntry.arguments?.getString("songId")
                val songId = songIdStr?.toLongOrNull()
                AdminAddEditSongScreen(
                    songId = songId,
                    adminViewModel = adminViewModel,
                    mainViewModel = mainViewModel,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = mainViewModel,
                    onOpenAdmin = {
                        if (adminViewModel.isAuthenticated.value) {
                            navController.navigate(Screen.AdminDashboard.route)
                        } else {
                            navController.navigate(Screen.AdminLogin.route)
                        }
                    },
                    onOpenAbout = {
                        navController.navigate(Screen.About.route)
                    }
                )
            }

            composable(Screen.About.route) {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
