package mg.jesosy.hery.fahefana.ui.viewmodels

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import mg.jesosy.hery.fahefana.data.local.CategoryEntity
import mg.jesosy.hery.fahefana.data.local.SongEntity
import mg.jesosy.hery.fahefana.data.repository.SongRepository

class AdminViewModel(
    private val repository: SongRepository,
    context: Context
) : ViewModel() {

    private val prefs: SharedPreferences = context.getSharedPreferences("admin_prefs", Context.MODE_PRIVATE)

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _operationStatus = MutableStateFlow<String?>(null)
    val operationStatus: StateFlow<String?> = _operationStatus.asStateFlow()

    private fun getSavedPin(): String {
        return prefs.getString("admin_pin", "7777") ?: "7777"
    }

    fun login(pin: String): Boolean {
        if (pin == getSavedPin()) {
            _isAuthenticated.value = true
            _loginError.value = null
            return true
        } else {
            _loginError.value = "Kaody PIN tsy marina. Andramo indray."
            return false
        }
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun changePin(oldPin: String, newPin: String): Boolean {
        if (oldPin != getSavedPin()) {
            _operationStatus.value = "Diso ny PIN taloha"
            return false
        }
        if (newPin.length < 4) {
            _operationStatus.value = "Ny PIN dia tsy maintsy farafahakeliny 4 tarehimarika"
            return false
        }
        prefs.edit().putString("admin_pin", newPin).apply()
        _operationStatus.value = "Voatahiry soa aman-tsara ny PIN vaovao"
        return true
    }

    fun saveSong(
        id: Long?,
        songNumber: Int,
        title: String,
        artist: String,
        categoryId: String,
        key: String?,
        tempo: String?,
        rawLyrics: String,
        tags: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            val song = SongEntity(
                id = id ?: 0L,
                songNumber = songNumber,
                title = title.trim(),
                artistOrAuthor = if (artist.isBlank()) "Mpihira Fiderana" else artist.trim(),
                categoryId = categoryId,
                tonalityKey = key?.ifBlank { null },
                tempo = tempo?.ifBlank { null },
                rawLyrics = rawLyrics.trim(),
                tags = tags.trim()
            )
            if (id == null || id == 0L) {
                repository.insertSong(song)
            } else {
                repository.updateSong(song)
            }
            _operationStatus.value = "Voatahiry ny hira"
            onComplete()
        }
    }

    fun deleteSong(song: SongEntity) {
        viewModelScope.launch {
            repository.deleteSong(song)
            _operationStatus.value = "Voafafa ny hira"
        }
    }

    fun saveCategory(
        id: String,
        name: String,
        malagasyName: String,
        desc: String?,
        icon: String,
        color: String
    ) {
        viewModelScope.launch {
            val category = CategoryEntity(
                id = id.trim().lowercase().replace(" ", "-"),
                name = name.trim(),
                malagasyName = malagasyName.trim(),
                description = desc?.ifBlank { null },
                iconName = icon,
                colorHex = color
            )
            repository.insertCategory(category)
            _operationStatus.value = "Voatahiry ny sokajy"
        }
    }

    fun deleteCategory(category: CategoryEntity) {
        viewModelScope.launch {
            repository.deleteCategory(category)
            _operationStatus.value = "Voafafa ny sokajy"
        }
    }

    fun clearStatus() {
        _operationStatus.value = null
    }
}

class AdminViewModelFactory(
    private val repository: SongRepository,
    private val context: Context
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AdminViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AdminViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
