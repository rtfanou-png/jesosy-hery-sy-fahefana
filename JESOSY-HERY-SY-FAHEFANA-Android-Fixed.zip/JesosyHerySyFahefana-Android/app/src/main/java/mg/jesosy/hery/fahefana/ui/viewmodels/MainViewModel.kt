package mg.jesosy.hery.fahefana.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import mg.jesosy.hery.fahefana.data.local.CategoryEntity
import mg.jesosy.hery.fahefana.data.local.SongEntity
import mg.jesosy.hery.fahefana.data.repository.SongRepository

class MainViewModel(private val repository: SongRepository) : ViewModel() {

    val allSongs: StateFlow<List<SongEntity>> = repository.allSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteSongs: StateFlow<List<SongEntity>> = repository.favoriteSongs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategories: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<SongEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allSongs
            else repository.searchSongs(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val categorySongs: StateFlow<List<SongEntity>> = _selectedCategory
        .flatMapLatest { catId ->
            if (catId == null) repository.allSongs
            else repository.getSongsByCategory(catId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reader state
    private val _fontSize = MutableStateFlow(16)
    val fontSize: StateFlow<Int> = _fontSize.asStateFlow()

    private val _isAutoScrolling = MutableStateFlow(false)
    val isAutoScrolling: StateFlow<Boolean> = _isAutoScrolling.asStateFlow()

    private val _scrollSpeed = MutableStateFlow(3)
    val scrollSpeed: StateFlow<Int> = _scrollSpeed.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(catId: String?) {
        _selectedCategory.value = catId
    }

    fun toggleFavorite(song: SongEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(song.id, !song.isFavorite)
        }
    }

    suspend fun getSongById(songId: Long): SongEntity? {
        return repository.getSongById(songId)
    }

    fun increaseFontSize() {
        if (_fontSize.value < 28) _fontSize.value += 2
    }

    fun decreaseFontSize() {
        if (_fontSize.value > 12) _fontSize.value -= 2
    }

    fun setAutoScrolling(active: Boolean) {
        _isAutoScrolling.value = active
    }

    fun setScrollSpeed(speed: Int) {
        _scrollSpeed.value = speed.coerceIn(1, 10)
    }
}

class MainViewModelFactory(private val repository: SongRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
