package mg.jesosy.hery.fahefana.data.local

object SampleData {
    val categories = listOf(
        CategoryEntity(
            id = "fiderana",
            name = "Fiderana sy Dera",
            malagasyName = "Fiderana sy Dera",
            description = "Hira fiderana sy fanandratana an’Andriamanitra",
            iconName = "Crown",
            colorHex = "#D4AF37"
        ),
        CategoryEntity(
            id = "fisaorana",
            name = "Fisaorana sy Fankasitrahana",
            malagasyName = "Fisaorana sy Fankasitrahana",
            description = "Hira fisaorana noho ny fitahiany",
            iconName = "HeartHandshake",
            colorHex = "#A78BFA"
        ),
        CategoryEntity(
            id = "vavaka",
            name = "Vavaka sy Fitarainana",
            malagasyName = "Vavaka sy Fitarainana",
            description = "Fitalahoana sy fitokiana eo anatrehan’ny Tompo",
            iconName = "HandMetal",
            colorHex = "#F472B6"
        ),
        CategoryEntity(
            id = "fampaherezana",
            name = "Fampaherezana sy Fanantenana",
            malagasyName = "Fampaherezana sy Fanantenana",
            description = "Faherezana ao anatin’ny ady sy fitsapana",
            iconName = "Shield",
            colorHex = "#34D399"
        ),
        CategoryEntity(
            id = "fanahy-masina",
            name = "Fanahy Masina",
            malagasyName = "Fanahy Masina",
            description = "Fikatsahana ny herin’ny Fanahy Masina",
            iconName = "Flame",
            colorHex = "#FBBF24"
        ),
        CategoryEntity(
            id = "famonjena",
            name = "Famonjena sy Hazofijaliana",
            malagasyName = "Famonjena sy Hazofijaliana",
            description = "Ny ràn’i Jesosy sy ny famonjena antsika",
            iconName = "Cross",
            colorHex = "#EF4444"
        ),
        CategoryEntity(
            id = "fanoloran-tena",
            name = "Fanoloran-tena",
            malagasyName = "Fanoloran-tena sy Fankatoavana",
            description = "Fanaterana ny fiainana manontolo ho an’i Jesosy",
            iconName = "Sparkles",
            colorHex = "#60A5FA"
        )
    )

    val songs = listOf(
        SongEntity(
            id = 1,
            songNumber = 1,
            title = "Jesosy No Hery Sy Fahefana",
            artistOrAuthor = "Tendry Fanomezantsoa R.",
            categoryId = "fiderana",
            tonalityKey = "Do (C)",
            tempo = "Velona sy Mahery",
            isFavorite = true,
            tags = "hery, fahefana, fiderana, fandresena",
            rawLyrics = """Andininy 1:
Jesosy no heriko sy ampingako,
Tsy manan-tahotra intsony aho;
Eo an-tanany ny fiainako manontolo,
Izy no Mpanjakan’ny mpanjaka rehetra.

Fiverenana:
Jesosy no Hery, Jesosy no Fahefana,
Ny anarany no avo indrindra eto an-tany;
Mandrakizay Izy no manjaka,
Haleloia, dera ho Anao ry Tompo!

Andininy 2:
Na dia maizina aza ny lalako,
Ny fahazavany no manazava;
Ny herin’ny maizina resiny teo Kalvary,
Fandresena no anjarantsika ankehitriny.

Andininy 3:
Koa manandrata feo ry mino rehetra,
Derao ilay Mpamonjy be fitiavana;
Fa Izy no vatolampy tsy mba mihozongozona,
Jesosy Tompo, Mahery sy Mahery indrindra!"""
        ),
        SongEntity(
            id = 2,
            songNumber = 2,
            title = "Tompo Ô, Misaotra Anao Izahay",
            artistOrAuthor = "Fihirana Fiderana",
            categoryId = "fisaorana",
            tonalityKey = "Sol (G)",
            tempo = "Tony sy Misaotra",
            isFavorite = true,
            tags = "fisaorana, fitahiana, fahasoavana",
            rawLyrics = """Andininy 1:
Tompo ô, misaotra Anao izahay,
Noho ny fahasoavanao tondraka;
Isa-maraina vaovao hatrany,
Ny fitiavanao tsy mba mety lany.

Fiverenana:
Misaotra Tompo ô! Misaotra ry Ray!
Fa lehibe loatra ny hatsaranao;
Tsy manan-kavaly izahay ry Tompo,
Koa ny fonay no atolotray ho Anao.

Andininy 2:
Na tamin’ny mora na tamin’ny sarotra,
Teo anilanao tsy nisy fandaozana;
Tantanan’ny tananao mahery,
Fiarovana azo antoka mandrakizay."""
        ),
        SongEntity(
            id = 3,
            songNumber = 3,
            title = "Miantsoa An’i Jesosy",
            artistOrAuthor = "Mpihira Fiderana",
            categoryId = "vavaka",
            tonalityKey = "Re (D)",
            tempo = "Tony",
            isFavorite = false,
            tags = "vavaka, vonjy, finoana",
            rawLyrics = """Andininy 1:
Raha sendra manjombona ny androko,
Ka toa lavitra ahy ny famonjena;
Iza indray no hitarainako?
Jesosy iray ihany no valin-teniko.

Fiverenana:
Miantsoa An’i Jesosy amin’ny fo madio,
Fa akaiky Izy ary vonona hihaino;
Tsy handao anao na oviana na oviana,
Fa Izy no Mpamonjy azo antoka.

Andininy 2:
Ento eo am-tongony ny enta-mavesatrao,
Izy hanome anao fitsaharana;
Ny ranomasonao hosorany ho fifaliana,
Miantsoa Azy anio dieny mbola azo atao."""
        ),
        SongEntity(
            id = 4,
            songNumber = 4,
            title = "Mijoroa Amin’ny Finoana",
            artistOrAuthor = "Hira Fampaherezana",
            categoryId = "fampaherezana",
            tonalityKey = "Mi (E)",
            tempo = "Mahery",
            isFavorite = false,
            tags = "finoana, herim-po, fandresena",
            rawLyrics = """Andininy 1:
Mijoroa amin’ny finoana ry zanak’Andriamanitra,
Aza manaiky ho resin’ny tahotra;
Ilay Kristy nitsangana tamin’ny maty,
No miady ho anao isan’andro.

Fiverenana:
Fandresena! Fandresena ao amin’i Jesosy!
Ny herin’ny lanitra miaraka amintsika;
Tsy hisy hahasaraka antsika amin’ny fitiavany,
Mijoroa, matokia, Izy no Tompo!

Andininy 2:
Na be aza ny onjan-dranomasina,
Ny feony no mampitsahatra ny tafiotra;
Izy no jeneraly mitarika antsika,
Ka tsy ho resy izay miara-dia Aminy."""
        ),
        SongEntity(
            id = 5,
            songNumber = 5,
            title = "Ny Herin’ny Fanahy Masina",
            artistOrAuthor = "Fanahy sy Fahamarinana",
            categoryId = "fanahy-masina",
            tonalityKey = "La (A)",
            tempo = "Afom-bavaka",
            isFavorite = false,
            tags = "fanahy, afo, hery, fitoriana",
            rawLyrics = """Andininy 1:
Midina ry Fanahy Masina ô!
Fenoy ny herinao ny fonay izao;
Manazavà, manadiova,
Mba ho vavolombelona marina izahay.

Fiverenana:
Afom-panahy, rano velona,
Tondraho izahay ankehitriny;
Mba hitorianay ny herin’i Jesosy,
Eto Madagasikara sy hatrany am-parany!

Andininy 2:
Toromy ny lalana tokony haleha,
Omeo hery handresy ny fakam-panahy;
Miantso Anao izahay miara-mivavaka,
Haleloia, avia ry Fanahy Masina!"""
        ),
        SongEntity(
            id = 6,
            songNumber = 6,
            title = "Teo Kalvary",
            artistOrAuthor = "Hira Famonjena",
            categoryId = "famonjena",
            tonalityKey = "Fa (F)",
            tempo = "Tony sy Mampihetsi-po",
            isFavorite = true,
            tags = "hazofijaliana, ra, famonjena",
            rawLyrics = """Andininy 1:
Teo Kalvary no nandoavanao ny trosako,
Ny ranao masina no nanasa ny heloko;
Fitiavana tsy manam-petra no nasehonao,
Fony Ianao nanolotra ny ainao ho ahy.

Fiverenana:
Isaorako Ianao ry Jesosy Mpamonjy,
Noho ny hazofijaliana teo Golgota;
Afaka tamin’ny fatorana aho anio,
Velona ao Aminao mandrakizay.

Andininy 2:
Tsy misy anarana hafa ankoatra ny Anao,
Izay manome fiainana sy fiadanana;
Teo amin’ny hazo no nandresenao ny fahafatesana,
Midera Anao ny fanahiko manontolo!"""
        ),
        SongEntity(
            id = 7,
            songNumber = 7,
            title = "Inty Aho Tompo Ô",
            artistOrAuthor = "Fanoloran-tena",
            categoryId = "fanoloran-tena",
            tonalityKey = "Do (C)",
            tempo = "Tony sy Fanolorana",
            isFavorite = false,
            tags = "fanolorana, fanompoana, fankatoavana",
            rawLyrics = """Andininy 1:
Inty aho Tompo ô, ampiasao araka ny sitrakao,
Ny saiko, ny heriko, ny fotoanako;
Apetrako eo an-tananao ny hoaviko,
Tsy te hiaina ho an’ny tenako intsony aho.

Fiverenana:
Irano aho, dia handeha aho,
Torio amin’ny alalako ny teninao;
Hanaiky Anao amin’ny foko rehetra aho,
Mandram-pahatongan’ny andro farany.

Andininy 2:
Tahio ny teny hotononiko,
Tahio ny asa hotontosaiko;
Mba ho voninahitrao irery ihany,
Ry Jesosy Tompoko sy Mpanjakako!"""
        )
    )
}
