package mg.jesosy.hery.fahefana.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.jesosy.hery.fahefana.ui.theme.*
import mg.jesosy.hery.fahefana.ui.viewmodels.AdminViewModel
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModel

@Composable
fun AdminDashboardScreen(
    viewModel: AdminViewModel,
    mainViewModel: MainViewModel,
    onAddSong: () -> Unit,
    onEditSong: (Long) -> Unit,
    onLogout: () -> Unit,
    onBack: () -> Unit
) {
    val songs by mainViewModel.allSongs.collectAsState()
    val categories by mainViewModel.allCategories.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }

    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    val status by viewModel.operationStatus.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dashboard Mpitantana",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = RoyalGold
            )
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark, contentColor = TextSecondaryDark),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("Hivoaka", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs: 0: Hira, 1: Sokajy, 2: Fiarovana (PIN)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SurfaceDark,
            contentColor = RoyalGold
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("Hira (" + songs.size + ")", modifier = Modifier.padding(10.dp), fontSize = 12.sp)
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("Sokajy (" + categories.size + ")", modifier = Modifier.padding(10.dp), fontSize = 12.sp)
            }
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                Text("PIN Fiarovana", modifier = Modifier.padding(10.dp), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (status != null) {
            Text(text = status!!, color = RoyalGold, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }

        when (selectedTab) {
            0 -> {
                // Songs List + Add Button
                Button(
                    onClick = onAddSong,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = ObsidianBlack),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("HAMPIDITRA HIRA VAOVAO", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(songs) { song ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardDark),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(song.songNumber.toString() + ". " + song.title, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                                    Text(song.artistOrAuthor, fontSize = 11.sp, color = TextSecondaryDark)
                                }

                                Row {
                                    IconButton(onClick = { onEditSong(song.id) }) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Edit", tint = RoyalGold)
                                    }
                                    IconButton(onClick = { viewModel.deleteSong(song) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Categories
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(categories) { cat ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CardDark),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(cat.name, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                                    Text(cat.description ?: "Sokajy", fontSize = 11.sp, color = TextSecondaryDark)
                                }
                                IconButton(onClick = { viewModel.deleteCategory(cat) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Security / Change PIN
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Hanova ny PIN Administrator", fontWeight = FontWeight.Bold, color = RoyalGold)

                    OutlinedTextField(
                        value = oldPin,
                        onValueChange = { oldPin = it },
                        placeholder = { Text("PIN taloha", color = TextMutedDark) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
                    )

                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it },
                        placeholder = { Text("PIN vaovao (farafahakeliny 4 tarehimarika)", color = TextMutedDark) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
                    )

                    Button(
                        onClick = {
                            viewModel.changePin(oldPin, newPin)
                            oldPin = ""
                            newPin = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = ObsidianBlack),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TEHIRIZO NY PIN VAOVAO", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
