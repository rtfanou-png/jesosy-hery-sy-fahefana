package mg.jesosy.hery.fahefana.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.jesosy.hery.fahefana.ui.navigation.Screen
import mg.jesosy.hery.fahefana.ui.theme.*

data class NavItem(
    val title: String,
    val route: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun BottomNavigationBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        NavItem("Fandraisana", Screen.Home.route, Icons.Filled.Home, Icons.Outlined.Home),
        NavItem("Tadiavo", Screen.Search.route, Icons.Filled.Search, Icons.Outlined.Search),
        NavItem("Sokajy", Screen.Categories.route, Icons.Filled.GridView, Icons.Outlined.GridView),
        NavItem("Mamin’ny fo", Screen.Favorites.route, Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder),
        NavItem("Fikirana", Screen.Settings.route, Icons.Filled.Settings, Icons.Outlined.Settings)
    )

    NavigationBar(
        containerColor = ObsidianBlack,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.route) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.title,
                        tint = if (isSelected) RoyalGold else TextMutedDark
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 10.sp,
                        color = if (isSelected) RoyalGold else TextMutedDark
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = SurfaceDark
                )
            )
        }
    }
}
