package mg.jesosy.hery.fahefana.data.repository

import kotlinx.coroutines.flow.Flow
import mg.jesosy.hery.fahefana.data.local.CategoryEntity
import mg.jesosy.hery.fahefana.data.local.SongDao
import mg.jesosy.hery.fahefana.data.local.SongEntity

class SongRepository(private val songDao: SongDao) {
    val allSongs: Flow<List<SongEntity>> = songDao.getAllSongs()
    val favoriteSongs: Flow<List<SongEntity>> = songDao.getFavoriteSongs()
    val allCategories: Flow<List<CategoryEntity>> = songDao.getAllCategories()

    suspend fun getSongById(id: Long): SongEntity? {
        return songDao.getSongById(id)
    }

    fun getSongsByCategory(categoryId: String): Flow<List<SongEntity>> {
        return songDao.getSongsByCategory(categoryId)
    }

    fun searchSongs(query: String): Flow<List<SongEntity>> {
        return songDao.searchSongs(query.trim())
    }

    suspend fun insertSong(song: SongEntity): Long {
        return songDao.insertSong(song)
    }

    suspend fun updateSong(song: SongEntity) {
        songDao.updateSong(song)
    }

    suspend fun deleteSong(song: SongEntity) {
        songDao.deleteSong(song)
    }

    suspend fun deleteSongById(songId: Long) {
        songDao.deleteSongById(songId)
    }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) {
        songDao.setFavorite(songId, isFavorite)
    }

    suspend fun insertCategory(category: CategoryEntity) {
        songDao.insertCategory(category)
    }

    suspend fun updateCategory(category: CategoryEntity) {
        songDao.updateCategory(category)
    }

    suspend fun deleteCategory(category: CategoryEntity) {
        songDao.deleteCategory(category)
    }

    suspend fun deleteCategoryById(categoryId: String) {
        songDao.deleteCategoryById(categoryId)
    }
}
