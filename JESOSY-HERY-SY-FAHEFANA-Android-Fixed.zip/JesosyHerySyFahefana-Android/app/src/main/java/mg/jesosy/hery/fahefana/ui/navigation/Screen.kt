package mg.jesosy.hery.fahefana.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Home : Screen("home")
    object Search : Screen("search")
    object Categories : Screen("categories")
    object Favorites : Screen("favorites")
    object LyricsReader : Screen("lyrics/{songId}") {
        fun createRoute(songId: Long) = "lyrics/" + songId
    }
    object AdminLogin : Screen("admin_login")
    object AdminDashboard : Screen("admin_dashboard")
    object AdminAddEditSong : Screen("admin_add_edit_song?songId={songId}") {
        fun createRoute(songId: Long? = null) = if (songId != null) "admin_add_edit_song?songId=" + songId else "admin_add_edit_song"
    }
    object Settings : Screen("settings")
    object About : Screen("about")
}
