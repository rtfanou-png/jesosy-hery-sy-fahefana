package mg.jesosy.hery.fahefana.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Category Entity for Song Organization
 */
@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val malagasyName: String,
    val description: String? = null,
    val iconName: String = "Crown",
    val colorHex: String = "#D4AF37"
)
