package mg.jesosy.hery.fahefana.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import mg.jesosy.hery.fahefana.ui.theme.ObsidianBlack
import mg.jesosy.hery.fahefana.ui.theme.RadiantGold
import mg.jesosy.hery.fahefana.ui.theme.RoyalGold

@Composable
fun SplashScreen(onAnimationEnd: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }

    val alphaAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
        label = "AlphaAnimation"
    )

    val scaleAnim = animateFloatAsState(
        targetValue = if (startAnimation) 1.05f else 0.8f,
        animationSpec = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
        label = "ScaleAnimation"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2600)
        onAnimationEnd()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF261A3D), ObsidianBlack),
                    radius = 1200f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .scale(scaleAnim.value)
                .alpha(alphaAnim.value)
        ) {
            Text(
                text = "✝",
                fontSize = 54.sp,
                color = RadiantGold
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "JESOSY HERY SY FAHEFANA",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = RoyalGold,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Lyrics Offline",
                fontSize = 14.sp,
                color = Color.LightGray
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Tahin Jesosy 🙏",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = RadiantGold
            )
        }
    }
}
