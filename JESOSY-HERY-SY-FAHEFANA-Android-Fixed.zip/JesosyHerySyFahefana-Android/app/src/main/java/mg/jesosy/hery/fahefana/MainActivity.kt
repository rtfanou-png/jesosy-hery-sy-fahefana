package mg.jesosy.hery.fahefana

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import mg.jesosy.hery.fahefana.ui.navigation.AppNavigation
import mg.jesosy.hery.fahefana.ui.theme.JesosyHeryTheme

/**
 * JESOSY HERY SY FAHEFANA - Lyrics Offline
 * Développé par Tendry Fanomezantsoa RAKOTONANAHARY (2026)
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JesosyHeryTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    AppNavigation(navController = navController)
                }
            }
        }
    }
}
