package mg.jesosy.hery.fahefana.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Editorial Dark Palette
val ObsidianBlack = Color(0xFF050505)
val SurfaceDark = Color(0xFF0E0E0E)
val CardDark = Color(0xFF141414)
val BorderDark = Color(0xFF222222)
val BorderSubtle = Color(0xFF1A1A1A)

// Christian Regal Gold
val RoyalGold = Color(0xFFD4AF37)
val RadiantGold = Color(0xFFE5C158)
val DeepGold = Color(0xFFB8860B)
val GoldMuted = Color(0x33D4AF37)

// Royal Accents
val DivinePurple = Color(0xFF8B5CF6)
val DeepPurple = Color(0xFF6D28D9)
val MysticViolet = Color(0xFF4C1D95)

// Text Colors
val TextPrimaryDark = Color(0xFFF5F5F5)
val TextSecondaryDark = Color(0xFFAAAAAA)
val TextMutedDark = Color(0xFF666666)

// Light Theme Palette
val LightBackground = Color(0xFFFBF9F5)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF5F0E6)
val LightBorder = Color(0xFFE6DEC9)
val TextPrimaryLight = Color(0xFF181512)
val TextSecondaryLight = Color(0xFF665E51)
