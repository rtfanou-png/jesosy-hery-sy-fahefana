package mg.jesosy.hery.fahefana.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.jesosy.hery.fahefana.ui.components.SongCard
import mg.jesosy.hery.fahefana.ui.theme.*
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModel

@Composable
fun CategoriesScreen(
    viewModel: MainViewModel,
    onSongClick: (Long) -> Unit
) {
    val categories by viewModel.allCategories.collectAsState()
    val selectedCatId by viewModel.selectedCategory.collectAsState()
    val categorySongs by viewModel.categorySongs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "Sokajin-kira",
            fontSize = 20.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            color = RoyalGold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                val isAllSelected = selectedCatId == null
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isAllSelected) RoyalGold else CardDark)
                        .clickable { viewModel.setSelectedCategory(null) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "Rehetra",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAllSelected) ObsidianBlack else TextPrimaryDark
                    )
                }
            }

            items(categories) { cat ->
                val isSelected = selectedCatId == cat.id
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) RoyalGold else CardDark)
                        .clickable { viewModel.setSelectedCategory(cat.id) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) ObsidianBlack else TextPrimaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Hira (" + categorySongs.size + ")",
            fontSize = 13.sp,
            color = TextSecondaryDark
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(categorySongs) { song ->
                SongCard(
                    song = song,
                    onClick = { onSongClick(song.id) },
                    onFavoriteToggle = { viewModel.toggleFavorite(song) }
                )
            }
        }
    }
}
