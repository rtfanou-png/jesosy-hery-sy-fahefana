package mg.jesosy.hery.fahefana.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * JESOSY HERY SY FAHEFANA - Song Database Entity
 */
@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val songNumber: Int,
    val title: String,
    val artistOrAuthor: String,
    val categoryId: String,
    val tonalityKey: String? = null,
    val tempo: String? = null,
    val rawLyrics: String,
    val tags: String = "",
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
