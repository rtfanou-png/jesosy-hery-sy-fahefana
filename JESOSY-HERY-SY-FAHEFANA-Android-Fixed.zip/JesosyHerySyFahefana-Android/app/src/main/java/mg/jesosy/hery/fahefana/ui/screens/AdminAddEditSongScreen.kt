package mg.jesosy.hery.fahefana.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mg.jesosy.hery.fahefana.ui.theme.*
import mg.jesosy.hery.fahefana.ui.viewmodels.AdminViewModel
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModel

@Composable
fun AdminAddEditSongScreen(
    songId: Long?,
    adminViewModel: AdminViewModel,
    mainViewModel: MainViewModel,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    var songNumber by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf("fiderana") }
    var tonalityKey by remember { mutableStateOf("") }
    var tempo by remember { mutableStateOf("") }
    var rawLyrics by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }

    LaunchedEffect(songId) {
        if (songId != null) {
            val song = mainViewModel.getSongById(songId)
            if (song != null) {
                songNumber = song.songNumber.toString()
                title = song.title
                artist = song.artistOrAuthor
                categoryId = song.categoryId
                tonalityKey = song.tonalityKey ?: ""
                tempo = song.tempo ?: ""
                rawLyrics = song.rawLyrics
                tags = song.tags
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = RoyalGold)
            }
            Text(
                text = if (songId == null) "Hampiditra Hira Vaovao" else "Hanova ny Hira",
                fontSize = 18.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = RoyalGold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = songNumber,
            onValueChange = { songNumber = it },
            label = { Text("Laharana (#)", color = TextSecondaryDark) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Lohatenin’ny Hira", color = TextSecondaryDark) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = artist,
            onValueChange = { artist = it },
            label = { Text("Mpanoratra / Mpihira", color = TextSecondaryDark) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = tonalityKey,
            onValueChange = { tonalityKey = it },
            label = { Text("Tonalité (Do, Sol, Re...)", color = TextSecondaryDark) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = rawLyrics,
            onValueChange = { rawLyrics = it },
            label = { Text("Tononkira manontolo (Andininy / Fiverenana)", color = TextSecondaryDark) },
            minLines = 8,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = tags,
            onValueChange = { tags = it },
            label = { Text("Tags / Teny fanalahidy", color = TextSecondaryDark) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimaryDark, unfocusedTextColor = TextPrimaryDark)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val num = songNumber.toIntOrNull() ?: 1
                adminViewModel.saveSong(
                    id = songId,
                    songNumber = num,
                    title = title,
                    artist = artist,
                    categoryId = categoryId,
                    key = tonalityKey,
                    tempo = tempo,
                    rawLyrics = rawLyrics,
                    tags = tags,
                    onComplete = onSaved
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = ObsidianBlack),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("TEHIRIZO NY HIRA", fontWeight = FontWeight.Bold)
        }
    }
}
