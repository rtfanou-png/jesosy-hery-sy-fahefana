package mg.jesosy.hery.fahefana.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import mg.jesosy.hery.fahefana.data.local.SongEntity
import mg.jesosy.hery.fahefana.ui.theme.*
import mg.jesosy.hery.fahefana.ui.viewmodels.MainViewModel

@Composable
fun LyricsReaderScreen(
    songId: Long,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var song by remember { mutableStateOf<SongEntity?>(null) }
    val fontSize by viewModel.fontSize.collectAsState()
    val isAutoScrolling by viewModel.isAutoScrolling.collectAsState()
    val scrollSpeed by viewModel.scrollSpeed.collectAsState()

    val scrollState = rememberScrollState()

    LaunchedEffect(songId) {
        song = viewModel.getSongById(songId)
    }

    // Auto-scroll loop
    LaunchedEffect(isAutoScrolling, scrollSpeed) {
        while (isAutoScrolling) {
            delay(120L / scrollSpeed)
            scrollState.scrollBy(2f)
        }
    }

    if (song == null) {
        Box(modifier = Modifier.fillMaxSize().background(ObsidianBlack), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = RoyalGold)
        }
        return
    }

    val currentSong = song!!

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = RoyalGold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Font size controls
                    IconButton(onClick = { viewModel.decreaseFontSize() }) {
                        Text("A-", color = RoyalGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    IconButton(onClick = { viewModel.increaseFontSize() }) {
                        Text("A+", color = RoyalGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    // Auto scroll toggle
                    IconButton(onClick = { viewModel.setAutoScrolling(!isAutoScrolling) }) {
                        Icon(
                            imageVector = if (isAutoScrolling) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Auto Scroll",
                            tint = if (isAutoScrolling) Color(0xFF34D399) else RoyalGold
                        )
                    }

                    // Favorite toggle
                    IconButton(onClick = {
                        viewModel.toggleFavorite(currentSong)
                        song = currentSong.copy(isFavorite = !currentSong.isFavorite)
                    }) {
                        Icon(
                            imageVector = if (currentSong.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (currentSong.isFavorite) Color(0xFFEF4444) else TextSecondaryDark
                        )
                    }

                    // Share
                    IconButton(onClick = {
                        val shareText = currentSong.songNumber.toString() + ". " + currentSong.title + "

" + currentSong.rawLyrics + "

— JESOSY HERY SY FAHEFANA (Offline)"
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, shareText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Hizara Tononkira"))
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = "Share", tint = TextSecondaryDark)
                    }
                }
            }
        },
        containerColor = ObsidianBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Song Header
            Text(
                text = currentSong.songNumber.toString() + ". " + currentSong.title,
                fontSize = (fontSize + 6).sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = RoyalGold,
                lineHeight = (fontSize + 10).sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            val tonalityStr = if (currentSong.tonalityKey != null) " • Tonalité: " + currentSong.tonalityKey else ""
            val tempoStr = if (currentSong.tempo != null) " • Tempo: " + currentSong.tempo else ""
            Text(
                text = currentSong.artistOrAuthor + tonalityStr + tempoStr,
                fontSize = 12.sp,
                color = TextSecondaryDark
            )

            Divider(
                color = BorderDark,
                modifier = Modifier.padding(vertical = 14.dp)
            )

            // Lyrics Body
            Text(
                text = currentSong.rawLyrics,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.6).sp,
                fontFamily = FontFamily.Serif,
                color = TextPrimaryDark
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
