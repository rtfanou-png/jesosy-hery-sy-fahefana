# Build APK depuis un smartphone

Ce projet contient un workflow GitHub Actions qui compile l'application sans Android Studio.

## Étapes
1. Créer un dépôt GitHub.
2. Envoyer tous les fichiers de ce projet à la racine du dépôt.
3. Ouvrir l'onglet **Actions**.
4. Choisir **Build Android APK** / **Build Android APK**.
5. Appuyer sur **Run workflow** si le workflow n'est pas lancé automatiquement.
6. Attendre la fin du build.
7. Ouvrir l'exécution réussie puis la section **Artifacts**.
8. Télécharger :
   - `JESOSY-HERY-SY-FAHEFANA-debug-APK` pour tester rapidement.
   - `JESOSY-HERY-SY-FAHEFANA-release-APK` pour la version release.

## Important
Le projet exporté ne contient pas `gradle-wrapper.jar`. Le workflow utilise donc
`gradle/actions/setup-gradle@v6` avec Gradle 8.10.2 et lance `gradle` directement.
